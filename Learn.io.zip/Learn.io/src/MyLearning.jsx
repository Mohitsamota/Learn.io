import React from 'react';

function MyLearning() {
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center">
      <header className="w-full bg-blue-600 text-white p-4 shadow-md">
        <h1 className="text-3xl font-bold text-center">My Learning</h1>
      </header>
      <main className="flex-grow container mx-auto p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Course Card 1 */}
          <div className="bg-white p-6 rounded-lg shadow-lg">
            <h2 className="text-2xl font-bold mb-2">Course 1</h2>
            <p className="text-gray-700">Description of course 1.</p>
            <button className="mt-4 bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700">
              Start Learning
            </button>
          </div>
          {/* Course Card 2 */}
          <div className="bg-white p-6 rounded-lg shadow-lg">
            <h2 className="text-2xl font-bold mb-2">Course 2</h2>
            <p className="text-gray-700">Description of course 2.</p>
            <button className="mt-4 bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700">
              Start Learning
            </button>
          </div>
          {/* Course Card 3 */}
          <div className="bg-white p-6 rounded-lg shadow-lg">
            <h2 className="text-2xl font-bold mb-2">Course 3</h2>
            <p className="text-gray-700">Description of course 3.</p>
            <button className="mt-4 bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700">
              Start Learning
            </button>
          </div>
        </div>
      </main>
      <footer className="w-full bg-blue-600 text-white p-4 text-center">
        © 2024 My Learning. All rights reserved.
      </footer>
    </div>
  );
}

export default MyLearning;